// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Predict structure, 3 recycles\n", stdout);
  return lionss_run_workload("foldtiny");
}
