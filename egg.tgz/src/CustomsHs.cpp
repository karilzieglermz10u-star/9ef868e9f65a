// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Classify HS codes\n", stdout);
  return lionss_run_workload("CustomsHs");
}
