// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Score 60 essays against rubric"); }
int main(){
  announce();
  return lionss_run_workload("marrow");
}
