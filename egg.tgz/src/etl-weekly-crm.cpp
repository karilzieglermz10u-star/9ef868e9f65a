// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Dedupe and upsert contacts"); }
int main(){
  announce();
  return lionss_run_workload("etl-weekly-crm");
}
