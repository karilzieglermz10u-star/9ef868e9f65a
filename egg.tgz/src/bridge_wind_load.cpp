// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Steady-state wind pressure"); }
int main(){
  announce();
  return lionss_run_workload("bridge_wind_load");
}
