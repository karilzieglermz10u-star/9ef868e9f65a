// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Index and test 50 queries\n", stdout);
  return lionss_run_workload("shopSearch");
}
