// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Timetable 18 classes without clashes\n", stdout);
  return lionss_run_workload("schoolTt");
}
