// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Two-phase solve, max 20 moves"); }
int main(){
  announce();
  return lionss_run_workload("rubik-kociemba");
}
