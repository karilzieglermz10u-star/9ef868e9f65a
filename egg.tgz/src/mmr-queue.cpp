// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Form 5v5 lobbies, max spread 120");
  std::fflush(stdout);
  return lionss_run_workload("mmr-queue");
}
