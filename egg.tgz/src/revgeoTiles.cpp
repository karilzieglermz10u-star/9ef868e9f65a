// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Reverse geocode to town\n", stdout);
  return lionss_run_workload("revgeoTiles");
}
