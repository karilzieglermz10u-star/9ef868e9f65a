// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Chinese-postman plow route"); }
int main(){
  announce();
  return lionss_run_workload("snowplow-arcs");
}
