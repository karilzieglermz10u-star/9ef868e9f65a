// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Translate with beam 4\n", stdout);
  return lionss_run_workload("mt_en_ja");
}
