// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fit 9-point polynomial map"); }
int main(){
  announce();
  return lionss_run_workload("gaze_calib");
}
