// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Polarity scoring\n", stdout);
  return lionss_run_workload("sentiment-reviews");
}
