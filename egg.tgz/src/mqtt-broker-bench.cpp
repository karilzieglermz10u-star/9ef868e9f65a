// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("1k publishers, QoS 1\n", stdout);
  return lionss_run_workload("mqtt-broker-bench");
}
