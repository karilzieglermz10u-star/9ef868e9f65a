// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Crew pairing, FTL rules"); }
int main(){
  announce();
  return lionss_run_workload("crewpair-eu");
}
