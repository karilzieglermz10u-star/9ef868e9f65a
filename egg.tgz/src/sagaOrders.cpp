// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Saga with compensation on step 3");
  std::fflush(stdout);
  return lionss_run_workload("sagaOrders");
}
