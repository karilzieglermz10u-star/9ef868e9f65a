// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Hammer token bucket\n", stdout);
  return lionss_run_workload("nimbus2");
}
