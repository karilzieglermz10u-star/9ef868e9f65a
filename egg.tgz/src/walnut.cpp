// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Lint 4k files with cache"); }
int main(){
  announce();
  return lionss_run_workload("walnut");
}
