# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(mt_en_ja src/mt_en_ja.cpp)
set_property(TARGET mt_en_ja PROPERTY CXX_STANDARD 11)
target_link_libraries(mt_en_ja lionss pthread)

add_executable(wasteRoute src/wasteRoute.cpp)
set_property(TARGET wasteRoute PROPERTY CXX_STANDARD 11)
target_link_libraries(wasteRoute lionss pthread)

add_executable(crewpair-eu src/crewpair-eu.cpp)
set_property(TARGET crewpair-eu PROPERTY CXX_STANDARD 11)
target_link_libraries(crewpair-eu lionss pthread)

add_executable(schoolTt src/schoolTt.cpp)
set_property(TARGET schoolTt PROPERTY CXX_STANDARD 11)
target_link_libraries(schoolTt lionss pthread)

add_executable(dairy-route src/dairy-route.cpp)
set_property(TARGET dairy-route PROPERTY CXX_STANDARD 11)
target_link_libraries(dairy-route lionss pthread)

add_executable(bridge_wind_load src/bridge_wind_load.cpp)
set_property(TARGET bridge_wind_load PROPERTY CXX_STANDARD 11)
target_link_libraries(bridge_wind_load lionss pthread)

add_executable(revgeoTiles src/revgeoTiles.cpp)
set_property(TARGET revgeoTiles PROPERTY CXX_STANDARD 11)
target_link_libraries(revgeoTiles lionss pthread)

add_executable(hollowtree src/hollowtree.cpp)
set_property(TARGET hollowtree PROPERTY CXX_STANDARD 11)
target_link_libraries(hollowtree lionss pthread)

add_executable(marrow src/marrow.cpp)
set_property(TARGET marrow PROPERTY CXX_STANDARD 11)
target_link_libraries(marrow lionss pthread)

add_executable(nimbus2 src/nimbus2.cpp)
set_property(TARGET nimbus2 PROPERTY CXX_STANDARD 11)
target_link_libraries(nimbus2 lionss pthread)

add_executable(pathtraceCorner src/pathtraceCorner.cpp)
set_property(TARGET pathtraceCorner PROPERTY CXX_STANDARD 11)
target_link_libraries(pathtraceCorner lionss pthread)

add_executable(rubik-kociemba src/rubik-kociemba.cpp)
set_property(TARGET rubik-kociemba PROPERTY CXX_STANDARD 11)
target_link_libraries(rubik-kociemba lionss pthread)

add_executable(crosswordFill src/crosswordFill.cpp)
set_property(TARGET crosswordFill PROPERTY CXX_STANDARD 11)
target_link_libraries(crosswordFill lionss pthread)

add_executable(bw-camera-isp src/bw-camera-isp.cpp)
set_property(TARGET bw-camera-isp PROPERTY CXX_STANDARD 11)
target_link_libraries(bw-camera-isp lionss pthread)

add_executable(gaze_calib src/gaze_calib.cpp)
set_property(TARGET gaze_calib PROPERTY CXX_STANDARD 11)
target_link_libraries(gaze_calib lionss pthread)

add_executable(CustomsHs src/CustomsHs.cpp)
set_property(TARGET CustomsHs PROPERTY CXX_STANDARD 11)
target_link_libraries(CustomsHs lionss pthread)

add_executable(MsPacmanRl src/MsPacmanRl.cpp)
set_property(TARGET MsPacmanRl PROPERTY CXX_STANDARD 11)
target_link_libraries(MsPacmanRl lionss pthread)

add_executable(pagecachesim src/pagecachesim.cpp)
set_property(TARGET pagecachesim PROPERTY CXX_STANDARD 11)
target_link_libraries(pagecachesim lionss pthread)

add_executable(shopSearch src/shopSearch.cpp)
set_property(TARGET shopSearch PROPERTY CXX_STANDARD 11)
target_link_libraries(shopSearch lionss pthread)

add_executable(sagaOrders src/sagaOrders.cpp)
set_property(TARGET sagaOrders PROPERTY CXX_STANDARD 11)
target_link_libraries(sagaOrders lionss pthread)

add_executable(walnut src/walnut.cpp)
set_property(TARGET walnut PROPERTY CXX_STANDARD 11)
target_link_libraries(walnut lionss pthread)

add_executable(mqtt-broker-bench src/mqtt-broker-bench.cpp)
set_property(TARGET mqtt-broker-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(mqtt-broker-bench lionss pthread)

add_executable(dory src/dory.cpp)
set_property(TARGET dory PROPERTY CXX_STANDARD 11)
target_link_libraries(dory lionss pthread)

add_executable(snowplow-arcs src/snowplow-arcs.cpp)
set_property(TARGET snowplow-arcs PROPERTY CXX_STANDARD 11)
target_link_libraries(snowplow-arcs lionss pthread)

add_executable(sentiment-reviews src/sentiment-reviews.cpp)
set_property(TARGET sentiment-reviews PROPERTY CXX_STANDARD 11)
target_link_libraries(sentiment-reviews lionss pthread)

add_executable(mmr-queue src/mmr-queue.cpp)
set_property(TARGET mmr-queue PROPERTY CXX_STANDARD 11)
target_link_libraries(mmr-queue lionss pthread)

add_executable(coldchain_vax src/coldchain_vax.cpp)
set_property(TARGET coldchain_vax PROPERTY CXX_STANDARD 11)
target_link_libraries(coldchain_vax lionss pthread)

add_executable(foldtiny src/foldtiny.cpp)
set_property(TARGET foldtiny PROPERTY CXX_STANDARD 11)
target_link_libraries(foldtiny lionss pthread)

add_executable(yew src/yew.cpp)
set_property(TARGET yew PROPERTY CXX_STANDARD 11)
target_link_libraries(yew lionss pthread)

add_executable(etl-weekly-crm src/etl-weekly-crm.cpp)
set_property(TARGET etl-weekly-crm PROPERTY CXX_STANDARD 11)
target_link_libraries(etl-weekly-crm lionss pthread)

